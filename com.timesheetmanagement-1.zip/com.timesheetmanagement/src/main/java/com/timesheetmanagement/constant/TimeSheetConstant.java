package com.timesheetmanagement.constant;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
public class TimeSheetConstant implements Serializable {

	public enum Status{
		SAVED,
		SUBMITTED,
		APPROVED,
		REJECTED
	}
}
