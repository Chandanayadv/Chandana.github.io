/*package com.timesheetmanagement.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Report {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Report rep;
	private Integer repDate;
	private Integer repPeriod;

	private Integer empId;
//private String empName;

	private Integer projId;
	private String projName;

	private long timeSheetId;
	private String timeSheetAct;
	private Date timeSheetDate;
	private String timeSheetOtherAct;
	private String timeSheetNoOfHours;

	public Report getRep() {
		return rep;
	}

	public void setRep(Report rep) {
		this.rep = rep;
	}

	public Integer getRepDate() {
		return repDate;
	}

	public void setRepDate(Integer repDate) {
		this.repDate = repDate;
	}

	public Integer getRepPeriod() {
		return repPeriod;
	}

	public void setRepPeriod(Integer repPeriod) {
		this.repPeriod = repPeriod;
	}

	public Set<TimeSheet> getReport() {
		return report;
	}

	public void setReport(Set<TimeSheet> report) {
		this.report = report;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public Integer getProjId() {
		return projId;
	}

	public void setProjId(Integer projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public long getTimeSheetId() {
		return timeSheetId;
	}

	public void setTimeSheetId(long timeSheetId) {
		this.timeSheetId = timeSheetId;
	}

	public String getTimeSheetAct() {
		return timeSheetAct;
	}

	public void setTimeSheetAct(String timeSheetAct) {
		this.timeSheetAct = timeSheetAct;
	}

	public Date getTimeSheetDate() {
		return timeSheetDate;
	}

	public void setTimeSheetDate(Date timeSheetDate) {
		this.timeSheetDate = timeSheetDate;
	}

	public String getTimeSheetOtherAct() {
		return timeSheetOtherAct;
	}

	public void setTimeSheetOtherAct(String timeSheetOtherAct) {
		this.timeSheetOtherAct = timeSheetOtherAct;
	}

	public String getTimeSheetNoOfHours() {
		return timeSheetNoOfHours;
	}

	public void setTimeSheetNoOfHours(String timeSheetNoOfHours) {
		this.timeSheetNoOfHours = timeSheetNoOfHours;
	}

	//@OneToMany(mappedBy = "report", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	//private Set<TimeSheet> report;
}*/