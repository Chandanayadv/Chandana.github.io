/*package com.timesheetmanagement.dao;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.repository.CrudRepository;

import com.timesheetmanagement.model.Report;
import com.timesheetmanagement.model.TimeSheet;

public interface ReportDAO extends CrudRepository<Report, Integer> {

	Optional<Report> findAllById(Set<TimeSheet> report);

}
*/