package com.timesheetmanagement.dao;




import org.springframework.data.jpa.repository.JpaRepository;


import com.timesheetmanagement.model.Employee;


public interface EmployeeDao extends JpaRepository<Employee, Integer>{

	Employee findByEmpUserName(String empUserName);

	


}
