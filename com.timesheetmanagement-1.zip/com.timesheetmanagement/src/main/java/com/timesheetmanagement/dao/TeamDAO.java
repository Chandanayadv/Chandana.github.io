package com.timesheetmanagement.dao;

import org.springframework.data.repository.CrudRepository;

import com.timesheetmanagement.model.Team;

public interface TeamDAO extends CrudRepository<Team, Integer> {

}
