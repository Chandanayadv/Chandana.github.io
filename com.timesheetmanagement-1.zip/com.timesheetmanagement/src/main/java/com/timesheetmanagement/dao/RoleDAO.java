package com.timesheetmanagement.dao;

import org.springframework.data.repository.CrudRepository;

import com.timesheetmanagement.model.Role;

public interface RoleDAO extends CrudRepository<Role, Integer> {

}
