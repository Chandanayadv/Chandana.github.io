package com.timesheetmanagement.dao;


import org.springframework.data.repository.CrudRepository;

import com.timesheetmanagement.model.Project;

public interface ProjectDAO extends CrudRepository<Project, Integer>{

	

}
