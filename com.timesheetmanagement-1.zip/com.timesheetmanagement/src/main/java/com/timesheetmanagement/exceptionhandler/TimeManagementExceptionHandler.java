package com.timesheetmanagement.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.exception.ProjectNotFoundException;
import com.timesheetmanagement.exception.RoleNotFoundException;
import com.timesheetmanagement.exception.TimeSheetNotFoundException;

@RestControllerAdvice
public class TimeManagementExceptionHandler {
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<Object> handleNonExistingEmployee(EmployeeNotFoundException exception) {
		return new ResponseEntity<>("Employee not found", HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ProjectNotFoundException.class)
	public ResponseEntity<Object> handleNonExistingProject(ProjectNotFoundException exception) {
		return new ResponseEntity<>("Project not found", HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(RoleNotFoundException.class)
	public ResponseEntity<Object> handleNonExistingRole(RoleNotFoundException exception) {
	return new ResponseEntity<>("Role not found", HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(TimeSheetNotFoundException.class)
	public ResponseEntity<Object> handleNonExistingTimeSheet(TimeSheetNotFoundException exception) {
	return new ResponseEntity<>("TimeSheet not found", HttpStatus.NOT_FOUND);
	}
}