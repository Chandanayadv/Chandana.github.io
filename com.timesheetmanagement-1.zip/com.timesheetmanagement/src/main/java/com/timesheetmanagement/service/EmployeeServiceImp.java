package com.timesheetmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timesheetmanagement.dao.EmployeeDao;
import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.exception.TimeSheetNotFoundException;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Login;
import com.timesheetmanagement.model.Role;
import com.timesheetmanagement.model.TimeSheet;

@Service
public class EmployeeServiceImp implements EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	@Autowired
	RoleService roleService;
	@Autowired
	TimeSheetService timeSheetService;

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return (List<Employee>) employeeDao.findAll();
	}

	@Override
	public Boolean addEmployee(Employee employee) throws EmployeeNotFoundException, TimeSheetNotFoundException {
		// TODO Auto-generated method stub
		
		
		if (employee != null) {
			employee.setEmpId(null);
			Role role=roleService.addRole(employee.getRoleId());
			TimeSheet tms = timeSheetService.addTimeSheet(employee.getTimeSheet());
			Employee emp = employeeDao.save(employee);
			return true;
		}
		return false;
	}

	@Override
	public Boolean updateEmployee(Employee employee) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> optional = employeeDao.findById(employee.getEmpId());
		if (optional.isPresent()) {
			Role role=roleService.addRole(employee.getRoleId());
			Employee emp = employeeDao.save(employee);
			return true;
		}
		return false;
	}

	

	@Override
	public Employee getEmployeeByName(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String login(Login login) throws EmployeeNotFoundException {
		Employee employee=(Employee) employeeDao.findByEmpUserName(login.getUsername());
				
		if(employee==null) {
			throw new EmployeeNotFoundException("user not exist");
		}
		if(!employee.getEmpPassword().equals(login.getPassword())) {
			return "password is not correct";
		}
		return "logged in successfully";
	}
	@Override
	public void delete(Integer empId) {
		employeeDao.deleteById(empId);
	}

}
