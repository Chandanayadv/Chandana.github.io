package com.timesheetmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timesheetmanagement.dao.EmployeeDao;
import com.timesheetmanagement.dao.RoleDAO;
import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Role;
@Service
public class RoleServiceImp implements RoleService {
	@Autowired
	RoleDAO roleDao;
	@Autowired
	EmployeeDao employeeDao;

	@Override
	public Role addRole(Role role) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		
		if (role != null) {
			role.setRoleId(null);
			Role rol = roleDao.save(role);
			return rol;
		}
		throw new EmployeeNotFoundException("not found");
	}

	@Override
	public Role updateRole(Role role) throws EmployeeNotFoundException {
		Optional<Role> optional = roleDao.findById(role.getRoleId());
		if (optional.isPresent()) {
			role.setRoleId(null);
			Role rol = roleDao.save(role);
			return rol;
		}
		throw new EmployeeNotFoundException("not found");
	}
	

	@Override
	public List<Role> getAllRole() {
		return (List<Role>) roleDao.findAll();
	}

	@Override
	public Boolean changeRole(Role role) {
		Optional<Role> optional = roleDao.findById(role.getRoleId());
		if (optional.isEmpty()) {
			return false;
		}
		roleDao.save(role);
		return true;
	}
	@Override
	public void delete(Integer empId) {
		employeeDao.deleteById(empId);
	}

}
