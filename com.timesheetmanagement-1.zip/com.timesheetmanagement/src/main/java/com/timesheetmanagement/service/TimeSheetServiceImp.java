package com.timesheetmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timesheetmanagement.dao.EmployeeDao;
import com.timesheetmanagement.dao.ProjectDAO;
import com.timesheetmanagement.dao.TimeSheetDAO;
import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.exception.TimeSheetNotFoundException;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Project;
import com.timesheetmanagement.model.TimeSheet;

@Service
public class TimeSheetServiceImp implements TimeSheetService{
	@Autowired
	TimeSheetDAO timeSheetDao;
	@Override
	public List<TimeSheet> getAllTimeSheet() {
		// TODO Auto-generated method stub
		return (List<TimeSheet>) timeSheetDao.findAll();
	}

	@Override
	public TimeSheet addTimeSheet(TimeSheet timeSheet) throws TimeSheetNotFoundException {
		// TODO Auto-generated method stub
		
		if (timeSheet!= null) {
			TimeSheet tms = timeSheetDao.save(timeSheet);
			return tms;
		}
		throw new TimeSheetNotFoundException("TimeSheet not found");
	}

	@Override
	public Boolean updateTimeSheet(TimeSheet timeSheet) {
		Optional<TimeSheet> optional = timeSheetDao.findById(timeSheet.getTimeSheetId());
		if (optional.isEmpty()) {
			return false;
		}
		timeSheetDao.save(timeSheet);
		return true;
	}
	@Override
	public Optional<TimeSheet> getTimeSheet(Integer empId) {
		return timeSheetDao.findById(empId);
	}


	/*@Override
	public void setProject(Project p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setManager(Employee e) {
		// TODO Auto-generated method stub
		
	}*/

}

