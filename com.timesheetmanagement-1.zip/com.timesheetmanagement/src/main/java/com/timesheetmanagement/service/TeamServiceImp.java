package com.timesheetmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timesheetmanagement.dao.EmployeeDao;
import com.timesheetmanagement.dao.ProjectDAO;
import com.timesheetmanagement.dao.TeamDAO;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Project;
import com.timesheetmanagement.model.Team;
@Service
public class TeamServiceImp implements TeamService {
	@Autowired
	TeamDAO teamDao;
	
	
	
	@Override
	public List<Team> getAllTeam() {
		// TODO Auto-generated method stub
		return (List<Team>) teamDao.findAll();
	}

	@Override
	public Boolean addTeam(Team team) {
		// TODO Auto-generated method stub
		Team tm = teamDao.save(team);
		if (tm != null) {
			return true;
		}
		return false;
	
	}

	@Override
	public Boolean updateTeam(Team team) {
		// TODO Auto-generated method stub
		Optional<Team> optional = teamDao.findById(team.getTeamId());
		if (optional.isEmpty()) {
			return false;
		}
		teamDao.save(team);
		return true;
	}

	@Override
	public void delete(Integer teamId) {
		teamDao.deleteById(teamId);
	}
	
	
	}
	


