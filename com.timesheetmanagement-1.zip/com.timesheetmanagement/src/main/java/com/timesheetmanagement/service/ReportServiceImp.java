/*
package com.timesheetmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timesheetmanagement.dao.ReportDAO;
import com.timesheetmanagement.model.Report;

@Service
	public abstract class ReportServiceImp implements ReportService { 
	
	@Autowired
	ReportDAO reportDao; 
	
	@Override
	public List<Report> getAllReport() {
	// TODO Auto-generated method stub
	return (List<Report>) reportDao.findAll();
	} 
	@Override
	public Boolean addReport(Report report) {
	// TODO Auto-generated method stub
	Report rep = reportDao.save(report);
	if (rep != null) {
	return true;
	}
	return false;
	} 
	@Override
	public Boolean updateReport(Report report) {
	// TODO Auto-generated method stub
	Optional<Report> optional = reportDao.findAllById(report.getReport());
	if (optional.isEmpty()) {
	return false;
	}
	reportDao.save(report);
	return true;
	}
	}

*/