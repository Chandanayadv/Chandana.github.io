package com.timesheetmanagement.service;

import java.util.List;

import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.exception.TimeSheetNotFoundException;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Login;

public interface EmployeeService {

	public List<Employee> getAllEmployee();
	public Boolean addEmployee(Employee employee) throws EmployeeNotFoundException, TimeSheetNotFoundException;
	public Boolean updateEmployee(Employee employee) throws EmployeeNotFoundException;
	
	public Employee getEmployeeByName(Employee employee);
	String login(Login login) throws EmployeeNotFoundException;
	void delete(Integer empId);
	
	
	
}
