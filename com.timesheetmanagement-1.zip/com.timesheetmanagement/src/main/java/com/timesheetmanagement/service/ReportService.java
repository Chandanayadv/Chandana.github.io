/*package com.timesheetmanagement.service;

import java.util.List;

import com.timesheetmanagement.model.Report;

public interface ReportService {
public List<Report> getAllReport();
public Boolean addReport(Report report);
Boolean updateReport(Report report);
public Boolean changeReport(Report report);
}

*/


