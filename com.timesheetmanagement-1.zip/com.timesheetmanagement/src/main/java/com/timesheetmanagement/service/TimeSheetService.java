package com.timesheetmanagement.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.transaction.annotation.Propagation;

import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.exception.TimeSheetNotFoundException;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Project;
import com.timesheetmanagement.model.TimeSheet;


public interface TimeSheetService {
	
	

	public List<TimeSheet> getAllTimeSheet();
	public TimeSheet addTimeSheet(TimeSheet timeSheet) throws TimeSheetNotFoundException;
	public Boolean updateTimeSheet(TimeSheet timeSheet);
	Optional<TimeSheet> getTimeSheet(Integer empId);
	

	/*public void setProject(Project p);

	public void setManager(Employee e);*/


	
	
}
