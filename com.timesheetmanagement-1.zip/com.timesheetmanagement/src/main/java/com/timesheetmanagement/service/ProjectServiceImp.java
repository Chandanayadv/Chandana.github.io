package com.timesheetmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timesheetmanagement.dao.EmployeeDao;
import com.timesheetmanagement.dao.ProjectDAO;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Project;

@Service
public class ProjectServiceImp implements ProjectService{

	@Autowired
	ProjectDAO projectDao;
	@Autowired
	EmployeeDao employeeDao;
	
	
	@Override
	public List<Project> getAllProject() {
		// TODO Auto-generated method stub
		return (List<Project>) projectDao.findAll();
	}

	@Override
	public Boolean addProject(Project project) {
		// TODO Auto-generated method stub
		Project pro = projectDao.save(project);
		if (pro != null) {
			return true;
		}
		return false;
	
	}

	@Override
	public Boolean updateProject(Project project) {
		// TODO Auto-generated method stub
		Optional<Project> optional = projectDao.findById(project.getProjId());
		if (optional.isEmpty()) {
			return false;
		}
		projectDao.save(project);
		return true;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return (List<Employee>) employeeDao.findAll();
	}
	@Override
	public void delete(Integer projId) {
		projectDao.deleteById(projId);
	}
	}
	

