package com.timesheetmanagement.service;

import java.util.List;

import com.timesheetmanagement.model.Team;

public interface TeamService {

	List<Team> getAllTeam();

	void delete(Integer teamId);

	Boolean updateTeam(Team team);

	Boolean addTeam(Team team);

}
