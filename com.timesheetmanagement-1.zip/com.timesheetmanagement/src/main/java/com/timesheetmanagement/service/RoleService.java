package com.timesheetmanagement.service;


import java.util.List;

import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.model.Role;

public interface RoleService {

	public Role addRole(Role role) throws EmployeeNotFoundException;

	public Role updateRole(Role role) throws EmployeeNotFoundException;

	public List<Role> getAllRole();

	public Boolean changeRole(Role role);

	void delete(Integer empId);
	
}
