package com.timesheetmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.timesheetmanagement.dao.EmployeeDao;
import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Login;
import com.timesheetmanagement.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	@GetMapping(value = "/employees", produces = { MediaType.APPLICATION_XML_VALUE })
	public List<Employee> getAllEmployee() throws EmployeeNotFoundException {
	List<Employee> employeeList = employeeService.getAllEmployee();
	if(employeeList==null) throw new EmployeeNotFoundException("Employee not found");
	return employeeList;
	}
	
	@PostMapping("/addemployee")
	public String addEmployee(@RequestBody Employee employee) throws EmployeeNotFoundException {
	Boolean isEmployeeAdded= employeeService.addEmployee(employee);
	if(isEmployeeAdded) {
	return "Employee added succeessfully";
	}
	else{
	return "unable to add employee";
	}
	}
	
	@PostMapping("/updateemployee")
	public String updateEmployee(@RequestBody Employee employee) throws EmployeeNotFoundException {
	Boolean flag = employeeService.updateEmployee(employee);
	if(flag == true) {
	return "Employee updated succeessfully";
	}
	else{
	return "unable to update employee";
	}
	}
	
	
	
	@GetMapping("/employee/{empId}")
	private void deleteEmp(@PathVariable("empId") Integer empId) {
		employeeService.delete(empId);
	}
	
	@PostMapping("/login")
	public String login(@RequestBody Login login) throws EmployeeNotFoundException {
		return employeeService.login(login);
		}
		
		
	}
	

