package com.timesheetmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.timesheetmanagement.exception.EmployeeNotFoundException;
import com.timesheetmanagement.model.Employee;
import com.timesheetmanagement.model.Project;
import com.timesheetmanagement.model.TimeSheet;
import com.timesheetmanagement.service.ProjectService;
import com.timesheetmanagement.service.TimeSheetService;
@RestController
public class TimeSheetController {

	@Autowired
	TimeSheetService timeSheetService;
	
	@GetMapping(value = "/timesheets")
	public List<TimeSheet> getAllTimeSheet() throws EmployeeNotFoundException {
	List<TimeSheet> timeSheetList = timeSheetService.getAllTimeSheet();
	if(timeSheetList==null) throw new EmployeeNotFoundException("TimeSheets is empty");
	return timeSheetList;
	}
	
	/*@PostMapping("/addtimesheets")
	public String addtimeSheet(@RequestBody TimeSheet timeSheet) {
	Boolean isTimesheetAdded=timeSheetService.addTimeSheet(timeSheet) ;
	if(isTimesheetAdded) {
	return "timesheet added succeessfully";
	}
	else{
	return "unable to add time";
	}
	}*/
	
	
	
}
