package com.timesheetmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.timesheetmanagement.model.Role;
import com.timesheetmanagement.service.RoleService;
@RestController
public class RoleController {

	
	@Autowired
	RoleService roleService;

	@GetMapping(value = "/roles", produces = { MediaType.APPLICATION_XML_VALUE })
	public List<Role> getAllRole() {
	List<Role> roleList = roleService.getAllRole();
	return roleList;
	}

	/*@PostMapping("/addRole")
	public String addRole(@RequestBody Role role) {
	Boolean isRoleAdded= roleService.addRole(role)
	if(isRoleAdded) {
	return "Role added succeessfully";
	}
	else{
	return "unable to add role";
	}
	}*/

	/*@PostMapping("/updateRole")
	public String updateRole(@RequestBody Role role) {
	Boolean flag = roleService.updateRole(role);
	if(flag == true) {
	return "Role updated succeessfully";
	}
	else{
	return "unable to update role";
	}
	}*/
	@PostMapping("/changeRole")
	public String changeRole(@RequestBody Role role) {
	Boolean flag = roleService.changeRole(role);
	if(flag == true) {
	return "role changed succeessfully";
	}
	else{
	return "unable to change";
	}
	}
	@GetMapping("/role/{empId}")
	private void deleteEmp(@PathVariable("empId") Integer empId) {
		roleService.delete(empId);
	}
	}
