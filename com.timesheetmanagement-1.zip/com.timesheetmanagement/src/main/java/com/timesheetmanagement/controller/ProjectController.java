package com.timesheetmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.timesheetmanagement.model.Project;
import com.timesheetmanagement.service.ProjectService;


@RestController
public class ProjectController {

	
	@Autowired
	ProjectService projectService;
	
	@GetMapping(value = "/project", produces = { MediaType.APPLICATION_XML_VALUE })
	public List<Project> getAllProjects() {
	List<Project> projectList =  projectService.getAllProject() ;
	return projectList;
	}
	
	@PostMapping("/addprojects")
	public String addProject(@RequestBody Project project) {
	Boolean isProjectAdded= projectService.addProject(project);
	if(isProjectAdded) {
	return "project added succeessfully";
	}
	else{
	return "unable to add project";
	}
	}
	
	@PostMapping("/updateproject")
	public String updateProject(@RequestBody Project project) {
	Boolean flag = projectService.updateProject(project);
	if(flag == true) {
	return "project updated succeessfully";
	}
	else{
	return "unable to update project";
	}
	}
	
}
