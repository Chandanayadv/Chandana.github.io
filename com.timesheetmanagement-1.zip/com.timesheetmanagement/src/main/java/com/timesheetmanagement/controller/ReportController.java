/*package com.timesheetmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.timesheetmanagement.model.Report;
import com.timesheetmanagement.service.ReportService;

@RestController
public class ReportController {

	@Autowired
	ReportService reportService;

	@GetMapping(value = "/reports", produces = { MediaType.APPLICATION_XML_VALUE })
	public List<Report> getAllReport() {
		List<Report> reportList = reportService.getAllReport();
		return reportList;
	}

	@PostMapping("/addReport")
	public String addReport(@RequestBody Report report) {
		Boolean isReportAdded = reportService.addReport(report);
		if (isReportAdded) {
			return "Report added succeessfully";
		} else {
			return "unable to add report";
		}
	}

	@PostMapping("/updateReport")
	public String updateReport(@RequestBody Report report) {
		Boolean flag = reportService.updateReport(report);
		if (flag == true) {
			return "Report updated succeessfully";
		} else {
			return "unable to update Report";
		}
	}

@PostMapping("/changeReport")
public String changeReport(@RequestBody Report report) {
Boolean flag = reportService.changeReport(report);
if(flag == true) {
return "Report changed succeessfully";
}
else{
return "unable to change Report";
}
}
}
*/