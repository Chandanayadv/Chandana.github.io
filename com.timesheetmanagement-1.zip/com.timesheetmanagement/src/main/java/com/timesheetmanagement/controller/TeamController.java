package com.timesheetmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.timesheetmanagement.model.Project;
import com.timesheetmanagement.model.Team;
import com.timesheetmanagement.service.ProjectService;
import com.timesheetmanagement.service.TeamService;
@RestController
public class TeamController {
	@Autowired
	TeamService teamService;
	
	@GetMapping(value = "/teams")
	public List<Team> getAllProjects() {
	List<Team> teamList =  teamService.getAllTeam();
	return teamList;
	}
	
	@PostMapping("/addteamss")
	public String addProject(@RequestBody Team team) {
	Boolean isTeamAdded= teamService.addTeam(team);
	if(isTeamAdded) {
	return "team added succeessfully";
	}
	else{
	return "unable to add team";
	}
	}
	
	@PostMapping("/updateteam")
	public String updateTeam(@RequestBody Team team) {
	Boolean flag = teamService.updateTeam(team);
	if(flag == true) {
	return "team updated succeessfully";
	}
	else{
	return "unable to update team";
	}
	}
}
